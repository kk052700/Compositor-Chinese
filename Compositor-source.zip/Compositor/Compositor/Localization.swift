import Foundation

/// Translates display text without changing enum raw values, document names, or accessibility identifiers.
/// English keys are the fallback for unsupported languages and missing translations.
nonisolated enum L10n {
    static func text(_ key: String, bundle: Bundle = .main) -> String {
        bundle.localizedString(forKey: key, value: key, table: "Localizable")
    }

    /// Use complete sentences with %@ placeholders so translations can reorder arguments.
    static func format(_ key: String, _ arguments: String...) -> String {
        String(format: text(key), locale: Locale.current, arguments: arguments)
    }
}
