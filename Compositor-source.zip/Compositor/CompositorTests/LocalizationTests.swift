import Testing
import Foundation
@testable import Compositor

struct LocalizationTests {
    private func bundle(_ language: String) throws -> Bundle {
        let path = try #require(Bundle.main.path(forResource: language, ofType: "lproj"))
        return try #require(Bundle(path: path))
    }

    @Test func chineseAndEnglishResourcesAreBundled() throws {
        let chinese = try bundle("zh-Hans")
        let english = try bundle("en")
        #expect(L10n.text("Save", bundle: chinese) == "保存")
        #expect(L10n.text("Save", bundle: english) == "Save")
        #expect(L10n.text("Untranslated fallback", bundle: chinese) == "Untranslated fallback")
        let title = L10n.text("Save changes to %@?", bundle: chinese)
        #expect(String(format: title, "100% artwork") == "要保存对“100% artwork”的更改吗？")
    }

    @Test func translatedBlendNamesKeepCompatibleProjectValues() throws {
        let chinese = try bundle("zh-Hans")
        #expect(L10n.text(LayerBlendMode.multiply.rawValue, bundle: chinese) == "正片叠底")
        for mode in LayerBlendMode.allCases {
            let data = try JSONEncoder().encode(mode)
            #expect(try JSONDecoder().decode(LayerBlendMode.self, from: data) == mode)
            #expect(try JSONDecoder().decode(String.self, from: data) == mode.rawValue)
        }
        #expect(LayerBlendMode.multiply.rawValue == "Multiply")
    }
}
