#!/usr/bin/env python3
"""Validate catalog coverage and format arguments without requiring Xcode."""
import json
from pathlib import Path
import re

root = Path(__file__).resolve().parents[1]
catalog = json.loads((root / "Compositor/Localizable.xcstrings").read_text())
entries = catalog["strings"]
assert catalog["sourceLanguage"] == "en"
for key, entry in entries.items():
    for language in ("en", "zh-Hans"):
        unit = entry["localizations"][language]["stringUnit"]
        assert unit["state"] == "translated" and unit["value"], (key, language)
        assert key.count("%@") == unit["value"].count("%@"), (key, language)
    assert entry["localizations"]["en"]["stringUnit"]["value"] == key

literal = r'"((?:[^"\\]|\\.)*)"'
missing = set()
for source in (root / "Compositor").rglob("*.swift"):
    for match in re.finditer(r'L10n\.(?:text|format)\(' + literal, source.read_text()):
        key = json.loads('"' + match[1] + '"')
        if key not in entries:
            missing.add((str(source.relative_to(root)), key))
assert not missing, f"Missing translations: {sorted(missing)}"
regions = (root / "Compositor.xcodeproj/project.pbxproj").read_text()
assert '"zh-Hans"' in regions
print(f"Validated {len(entries)} English/Simplified Chinese entries and all literal lookup keys.")
